#include "funzioni.h"
#include <iostream>
using namespace std;

int main(){

int grandezza;
cout << "Inserisci la grandezza dell' inventario";
cin >> grandezza;
prodotto inventario[grandezza];

int spazio = 0;
char scelta;
int cercato;

do
	{

		menu();
		cin >> scelta;

		switch(scelta)
		{
		   case '1': inserisci(inventario, spazio, grandezza);
                     break;
           case '2':
        	   {
        		   cout << "Scegli il codice del prodotto da eliminare: " <<endl;
        		   cin >> cercato;
        		   elimina(inventario, spazio, cercato);
        	   }
        	   	   break;
           case '3': ordina(inventario, spazio);
                     break;
           case '4':
           	   {
        	   	   cout << "Scegli il codice del prodotto da cercare: " <<endl;
        	   	   cin >> cercato;
                   cerca(inventario, spazio, cercato);
               }
                     break;
           case '5': stampa(inventario, spazio);
                     break;
           case '6': min(inventario, spazio);
                                break;
           case '7': cout << "Programma terminato" << endl;
                     break;


           default:  cout << scelta << " is invalid." << endl;


		}


}while(scelta != '7');

	return 0;
}
