#include <iostream>
#include "funzioni.h"
using namespace std;


void menu()
{
	cout << endl;
	cout << "Scegli cosa fare: " << endl;
	cout << "Premi '1' per inserire un nuovo prodotto " << endl;
	cout << "Premi '2' per eliminare un prodotto " << endl;
	cout << "Premi '3' per ordinare l'inventario in ordine crescente di codice " << endl;
	cout << "Premi '4' per cercare un prodotto " << endl;
	cout << "Premi '5' per stampare l'inventario" << endl;
	cout << "Premi '6' per trovare il prodotto con il minor prezzo di una categoria" << endl;
	cout << "Premi '7' per terminare il programma" << endl;
}

void inserisci(prodotto invent[], int& spazio, int grandezza)
{
	if(spazio == grandezza)
		{
			cout << "Non hai pi� spazio" << endl;
			return;
		}

	cout <<"Inserisci il nuovo prodotto: " << endl;

	cout <<"Nome: " << endl;
	cin >> invent[spazio].nome;

	cout <<"Produttore: " << endl;
	cin >> invent[spazio].produttore;

	cout <<"Prezzo: " << endl;
	cin >> invent[spazio].prezzo;

	cout <<"Codice: " << endl;
	cin >> invent[spazio].codice;

	cout <<"Quantit�: " << endl;
	cin >> invent[spazio].quant;

	cout <<"Categoria: " << endl;
	cin >> invent[spazio].categoria;

	spazio++;
}

int cerca(prodotto invent[], int spazio, int cercato)
{
	bool trovato = false;
	int i;

	for(i = 0; (i < spazio)&&(trovato == false); i++)
		{
			if(invent[i].codice == cercato)
				{
					trovato = true;

				}
		}

	i--;

	if (trovato == false)
		{
			cout << "Non ho trovato il tuo prodotto: " << endl;
			return -1;
		}

				cout <<"Il tuo prodotto �: " << endl;

				cout <<"Nome: " << invent[i].nome <<endl;
				cout <<"Produttore: " << invent[i].produttore <<endl;
				cout <<"Prezzo: " << invent[i].prezzo <<endl;
				cout <<"Quantit�: " << invent[i].quant<< endl;
				cout <<"Categoria: " << invent[i].categoria<< endl;

	return i;
}

void ordina(prodotto invent[], int spazio)
{
	int i, j, temp_codice, temp_quant;

	double temp_prezzo;

	string temp_produttore, temp_nome, temp_categoria;

	for(i = 0; i < spazio; i++)
		{
			for(j = i + 1; j < spazio; j++)
				{
					if(invent[j].codice < invent[i].codice)
						{
							temp_codice = invent[j].codice;
							invent[j].codice = invent[i].codice;
							invent[i].codice = temp_codice;

							temp_nome = invent[j].nome;
							invent[j].nome = invent[i].nome;
							invent[i].nome = temp_nome;

							temp_produttore = invent[j].produttore;
							invent[j].produttore = invent[i].produttore;
							invent[i].produttore = temp_produttore;

							temp_prezzo = invent[j].prezzo;
							invent[j].prezzo = invent[i].prezzo;
							invent[i].prezzo = temp_prezzo;

							temp_quant = invent[j].quant;
							invent[j].quant = invent[i].quant;
							invent[i].quant = temp_quant;

							temp_categoria = invent[j].categoria;
							invent[j].categoria = invent[i].categoria;
							invent[i].categoria = temp_categoria;
						}
				}
		}
}

void elimina(prodotto invent[], int& spazio, int cercato)
{
	char scelta;

	int i = cerca(invent, spazio, cercato);

	cout <<"Sei sicuro di volerlo eliminare? (s/n)";
	cin >> scelta;

	if(scelta == 's')
		{
			invent[i].nome = invent[spazio - 1].nome  ;
			invent[i].produttore = invent[spazio - 1].produttore ;
			invent[i].prezzo = invent[spazio - 1].prezzo ;
			invent[i].quant = invent[spazio - 1].quant;
			invent[i].codice = invent[spazio - 1].codice;
			invent[i].categoria = invent[spazio - 1].categoria;

		spazio--;
		}
	else
		{
			return;
		}
}

void stampa(prodotto invent[], int spazio)
{
	for(int i = 0; i < spazio; i++)
		{
			cout <<"Il " << i + 1  << " prodotto �: " << endl;
			cout <<"Nome: " << invent[i].nome <<endl;
			cout <<"Produttore: " << invent[i].produttore <<endl;
			cout <<"Prezzo: " << invent[i].prezzo <<endl;
			cout <<"Quantit�: " << invent[i].quant<< endl;
			cout <<"Codice: " << invent[i].codice<< '\n' <<endl;
			cout <<"Categoria: " << invent[i].categoria<< '\n' <<endl;
		}
}

void min(prodotto invent[], int spazio)
{

		double min = 100000;
		int i, j;

		cout << "Inserisci la categoria desiderata" << endl;;
		string cercato;
		cin >> cercato;

		for(i = 0; (i < spazio); i++)
			{
				if((invent[i].categoria == cercato) && (invent[i].prezzo < min))
					{
						min = invent[i].prezzo;
						j = i;
					}
			}

			cout <<"Il prodotto della categoria " << cercato <<" con il prezzo pi� basso �: " << endl;
			cout <<"Nome: " << invent[j].nome <<endl;
			cout <<"Produttore: " << invent[j].produttore <<endl;
			cout <<"Prezzo: " << invent[j].prezzo <<endl;
			cout <<"Quantit�: " << invent[j].quant<< endl;
			cout <<"Categoria: " << invent[j].categoria<< endl;
}
