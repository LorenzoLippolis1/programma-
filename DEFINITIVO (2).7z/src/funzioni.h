#include <iostream>

#ifndef FUNZIONI_H_
#define FUNZIONI_H_

struct prodotto{

std::string nome;

std::string produttore;

std::string categoria;

double prezzo;

int codice;

int quant;

};

void menu();

void inserisci(prodotto invent[], int& spazio, int grandezza);

int cerca(prodotto invent[], int spazio, int cercato);

void ordina(prodotto invent[], int spazio);

void elimina(prodotto invent[], int& spazio, int cercato);

void stampa(prodotto invent[], int spazio);

void min(prodotto invent[], int spazio);

#endif /* FUNZIONI_H_ */
